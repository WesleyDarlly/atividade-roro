DROP TABLE IF EXISTS users;

CREATE TABLE users (
    matricula TEXT NOT NULL,
    email TEXT NOT NULL,
    senha TEXT NOT NULL    
);

CREATE TABLE exercicios (
    nome TEXT NOT NULL,
    descricao TEXT NOT NULL,
    email TEXT NOT NULL
)