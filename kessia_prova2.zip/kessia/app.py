from flask import Flask, redirect, render_template, url_for, request, flash
import sqlite3
from models import User
from werkzeug.security import check_password_hash, generate_password_hash

from flask_login import LoginManager, login_user, login_required, logout_user
login_manager = LoginManager()

app = Flask(__name__)

login_manager.init_app(app)

app.config['SECRET_KEY'] = 'DIFICIL'

@login_manager.user_loader
def load_user(user_matricula):
    return User.get(user_matricula)

@app.route('/')
def index():    
    return render_template('index.html',users = User.all())

@app.route('/usuario', methods=['POST', 'GET'])
def usuario():
    if request.method == 'POST':
        matricula= request.form['matricula']
        email = request.form['email']
        password = request.form['password']        
        if not User.exists(email):
            user = User(matricula=matricula, email=email, password=password)
            user.save()            
            login_user(user)
            flash("Cadastro realizado com sucesso")
            return redirect(url_for('dash'))
    return render_template('cad_usuario.html')

@app.route('/exercicio', methods=['POST', 'GET'])
@login_required
def exercicio():
    if request.method == 'POST':
        email = request.form['email']     
        if not User.exists(email):
            user = User(email=email)
            user.save()            
            login_user(user)
            return redirect(url_for('index'))
    return render_template('cad_exercicio.html')

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']   
        user = User.get_by_email(email)
        if check_password_hash(user['senha'], password):
            login_user(User.get(user['matricula']))
            return redirect(url_for('index'))
        else:
            return redirect(url_for('login'))
    return render_template('login.html')
             
@app.route('/dashboard')
def dash():
    return render_template('dash.html')